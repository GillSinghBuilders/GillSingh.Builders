# Gill Singh Builders Website

This is a modern, multi-section, responsive website template created for **Gill Singh Builders**.

## 📂 Project Structure
- `index.html` – Main website file
- `styles.css` – Styling for the website
- `script.js` – JavaScript for interactivity (e.g., contact form)
- `assets/hero.jpg` – Placeholder hero image (replace with your own)

## 🚀 How to Use
1. Download and unzip the project folder.
2. Open `index.html` in your browser to preview the site locally.
3. Replace `assets/hero.jpg` with your own high-quality image for the hero section.
4. Edit text, services, and contact details in `index.html` to customize for your business.

## 🌐 How to Deploy (Free Hosting Options)
### Option 1: GitHub Pages
1. Create a GitHub account (if not already).
2. Create a new repository and upload these files.
3. Go to repository **Settings > Pages**.
4. Choose branch `main` and root folder `/`.
5. Your site will be live at `https://your-username.github.io/repo-name`.

### Option 2: Netlify (Drag & Drop)
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag and drop the unzipped folder.
3. Netlify will give you a live URL instantly.

### Option 3: Vercel
1. Go to [https://vercel.com](https://vercel.com) and sign in.
2. Import project from GitHub or upload manually.
3. Vercel will deploy your site and provide a live link.

## ✨ Features
- Modern, clean, and elegant design (navy + gold theme).
- Responsive layout for desktop and mobile.
- Multi-section (About, Services, Projects, Testimonials, Contact).
- Contact form with JavaScript alert (can be connected to email service).

---
© 2025 Gill Singh Builders. All rights reserved.
